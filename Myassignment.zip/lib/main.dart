import 'package:flutter/material.dart';



void main() {
  runApp(MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      home: Scaffold(
        appBar: AppBar(
          title: const Text('My Profile'),
        ),
        body: const Center(
          child: Text(
            'My Name is: Mujeeb Sheikh\n'
            'My Hobbies is Playing Cricket, Reading Books\n'
            'Skills:Graphic Designing\n'
            'Profession: Business Man', 
            style: TextStyle(fontSize: 18.0),
          ),
        ),
      ),
    );
  }
}


