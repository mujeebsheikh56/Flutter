import 'package:flutter_test/flutter_test.dart';
import 'package:myassignment/main.dart';  // Update this path to the location of your ShopApp widget

void main() {
  testWidgets('MyApp smoke test', (WidgetTester tester) async {
    // Build our app and trigger a frame.
    await tester.pumpWidget(ShopApp());

    // Verify that the title of the AppBar is displayed.
    expect(find.text('Stylish'), findsOneWidget);

    // Verify that the "50-60% OFF" text is displayed.
    expect(find.text('50-60% OFF'), findsOneWidget);
  });
}
