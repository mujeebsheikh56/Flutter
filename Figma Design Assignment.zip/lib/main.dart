import 'package:flutter/material.dart';

void main() {
  runApp(ShopApp());
}

class ShopApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Stylish Shop',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: HomePage(),
    );
  }
}

class HomePage extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Stylish'),
        actions: [
          IconButton(
            icon: Icon(Icons.account_circle),
            onPressed: () {
              // Handle profile icon press
            },
          ),
        ],
      ),
      drawer: Drawer(
        child: ListView(
          children: <Widget>[
            DrawerHeader(
              child: Text('Menu'),
              decoration: BoxDecoration(
                color: Colors.blue,
              ),
            ),
            ListTile(
              title: Text('Beauty'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Fashion'),
              onTap: () {},
            ),
            ListTile(
              title: Text('Kids'),
              onTap: () {},
            ),
            ListTile(
              title: Text('More'),
              onTap: () {},
            ),
          ],
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          children: <Widget>[
            BannerSection(),
            DealOfTheDay(),
            SpecialOffers(),
            FlatAndHeels(),
            TrendingProducts(),
            NewArrivals(),
          ],
        ),
      ),
    );
  }
}

class BannerSection extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.pinkAccent,
      padding: EdgeInsets.all(20),
      child: Column(
        children: [
          Text(
            '50-60% OFF',
            style: TextStyle(fontSize: 24, color: Colors.white),
          ),
          Text(
            'Now in products',
            style: TextStyle(fontSize: 18, color: Colors.white),
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {},
            child: Text('Shop Now'),
          ),
        ],
      ),
    );
  }
}

class DealOfTheDay extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.blue,
      padding: EdgeInsets.all(20),
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        children: [
          Text(
            'Deal of the Day',
            style: TextStyle(fontSize: 18, color: Colors.white),
          ),
          Text(
            '22h 55m 20s running',
            style: TextStyle(fontSize: 14, color: Colors.white),
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {},
            child: Text('View all'),
          ),
        ],
      ),
    );
  }
}

class SpecialOffers extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20),
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        children: [
          Text(
            'Special Offers',
            style: TextStyle(fontSize: 18),
          ),
          Text(
            'We ensure you get the best offers',
            style: TextStyle(fontSize: 14),
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {},
            child: Text('View now'),
          ),
        ],
      ),
    );
  }
}

class FlatAndHeels extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20),
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        children: [
          Text(
            'Flat and Heels',
            style: TextStyle(fontSize: 18),
          ),
          Text(
            'Stand a chance to get 50% off',
            style: TextStyle(fontSize: 14),
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {},
            child: Text('Visit now'),
          ),
        ],
      ),
    );
  }
}

class TrendingProducts extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      color: Colors.pinkAccent,
      padding: EdgeInsets.all(20),
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        children: [
          Text(
            'Trending Products',
            style: TextStyle(fontSize: 18, color: Colors.white),
          ),
          Text(
            'Last Date 20/02/22',
            style: TextStyle(fontSize: 14, color: Colors.white),
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {},
            child: Text('View all'),
          ),
        ],
      ),
    );
  }
}

class NewArrivals extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.all(20),
      margin: EdgeInsets.symmetric(vertical: 10),
      child: Column(
        children: [
          Text(
            'New Arrivals',
            style: TextStyle(fontSize: 18),
          ),
          Text(
            'Summer\' 25 Collections',
            style: TextStyle(fontSize: 14),
          ),
          SizedBox(height: 10),
          ElevatedButton(
            onPressed: () {},
            child: Text('View all'),
          ),
        ],
      ),
    );
  }
}
