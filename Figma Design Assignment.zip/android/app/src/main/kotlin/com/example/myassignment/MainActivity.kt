package com.example.myassignment

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
